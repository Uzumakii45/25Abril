//DEFINIMOS VARIABLES GLOBALES

const d = document;
let nameInput = d.querySelector("#productos-select");
let priceInput = d.querySelector("#precio-pro");
let srockInput = d.querySelector("#stoke-pro");
let descripcionInput = d.querySelector("#descripcion-pro");
let imagen = d.querySelector("#imagen-pro");
let btnCreate = d.querySelector("#btn-create");
let pruductUpdate;


//AGREGAMOS EVENTO AL BOTON
btnCreate.addEventListener("click", () => {
    alert(nameInput.value);

})

//VALIDAR EL FORMULAR Y OBTENER LOS DATOS DEL PRODUCTO 

let getDataproduct = () =>{
    let getData = ()=>{
        //validar formulario
        let product;
        if (nameInput.value && preciInput.value && stockInput.value && descripcionInput.value && imagen.src) {
          product= {
            name: nameInput.value,
            descripcion: descripcionInput.value,
            precio: precioInput.value,
            stock: srockInput.value,
            imagen: imagen.src
          };
          nameInput.value= "";
          descripcionInput.value = "";
          priceInput.value = "";
          stockInput.value = 10;
          imagen.src = "https://m.media-amazon.com/images/I/61XV8PihCwL._SY250_.jpg";
             console.log(product);
            
        }else{
            alert("** El usuario y la contraseña son obligatorios **")
        }
       
        return user;
    };
}



