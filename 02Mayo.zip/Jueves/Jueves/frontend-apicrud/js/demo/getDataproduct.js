//VALIDAR EL FORMULAR Y OBTENER LOS DATOS DEL PRODUCTO 
let getDataproduct = () => {
    let getData = () => {
        //validar formulario
        let product;
        if (nameInput.value && preciInput.value && stockInput.value && descripcionInput.value && imagen.src) {
            product = {
                name: nameInput.value,
                descripcion: descripcionInput.value,
                precio: preciInput.value
            };
            userInput.value = "";
            contraInput.value = "";
            console.log(user);

        } else {
            alert("** El usuario y la contraseña son obligatorios **");
        }

        return user;
    };
};
