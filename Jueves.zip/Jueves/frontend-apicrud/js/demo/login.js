const d = document;
let userInput = d.querySelector("#usuarioForm")
let contraInput = d.querySelector("#Password")
let btnLogin = d.querySelector(".btnLogin")


btnLogin.addEventListener("click", ()=>{
    //alert("escribio" + userInput.value)
    let user = getData();
    sendData(getData);
})

//Funcion para validar datos  y obtener las credenciales

let getData = ()=>{
    //validar formulario
    let user;
    if (userInput.value && contraInput.value) {
      user = {
        usuarios: userInput.value,
        contrasena:contraInput.value
      }
      userInput.value = "";
      contraInput.value = "";
      console.log(user);
        
    }else{
        alert("** El usuario y la contraseña son obligatorios **")
    }
   
    return user;
};

let sendData = async (data)=>{
    let url = "http://localhost/backend-apiCrud/login"
    try {
        
    let respuesta = await fetch(url,{
        method: "POST",
        headers:{
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    });
        if (respuesta.status == 401) {
            alert ("El usuario y/o contraseña es incorrecta")
            
        }else{
            let userData = await respuesta.json();
            alert("Bienvenido " + userData.nombre)
            location.href ="../index.html";
            console.log(userData)
        }

  
    
    } catch (error) {
        console.log("error:" + error)
        
    }



}